# Trenna Distribuição — Plataforma de Vendas (com login, papéis e descontos)

Sistema completo com backend real (Node.js, zero dependências de terceiros), banco de dados persistente (SQLite), autenticação, três papéis de usuário (cliente, vendedor, administrador), motor de desconto de primeira compra/desconto atribuído, e tema **Outubro Rosa**.

---

## 1. Arquitetura — o que mudou e por quê

A versão anterior do site era 100% estática (HTML/CSS/JS, sem servidor). Este pedido exigia login de verdade, papéis de usuário, descontos calculados com segurança e histórico de pedidos — **nada disso pode existir sem um servidor com estado e um banco de dados**. Por isso, a partir desta versão, o projeto é uma aplicação Node.js com backend real.

**Decisão importante de arquitetura:** este backend não usa nenhuma biblioteca de terceiros (nada de Express, bcrypt, etc.) — só módulos nativos do Node.js (`node:http`, `node:crypto`, `node:sqlite`). Isso foi uma escolha deliberada, não uma limitação disfarçada: significa que o projeto roda em **qualquer lugar com Node.js 22.5+ instalado, sem precisar rodar `npm install`, sem risco de uma dependência quebrar daqui a um ano**. Se quiserem adicionar Express/Prisma/etc. depois, o código está organizado para isso ser uma troca localizada (ver `server/router.js` e `server/db.js`).

```
trenna-app/
├── server/
│   ├── index.js            ← ponto de entrada (sobe o servidor HTTP)
│   ├── db.js                ← conexão SQLite + migrações
│   ├── router.js            ← roteador HTTP mínimo (sem Express)
│   ├── static.js            ← serve os arquivos de public/
│   ├── migrations/001_init.sql
│   ├── lib/
│   │   ├── password.js      ← hash de senha (scrypt)
│   │   ├── session.js       ← cookies de sessão + CSRF
│   │   ├── ratelimit.js     ← limite de tentativas (login/recuperação)
│   │   ├── mailer.js        ← envio de e-mail (plugável — ver seção 8)
│   │   ├── audit.js         ← log de auditoria
│   │   └── discount.js      ← motor de desconto (a parte mais sensível)
│   └── routes/
│       ├── auth.js, catalog.js, customer.js, rep.js, admin.js
├── public/                  ← tudo que é servido ao navegador
│   ├── index.html            ← site público (catálogo + carrinho "visitante")
│   ├── login.html, forgot-password.html, reset-password.html
│   ├── dashboard-customer.html, dashboard-rep.html, dashboard-admin.html
│   └── assets/ (css, js, imagens dos produtos)
├── data/
│   ├── products-source.json, product-images-source.json  ← catálogo de origem
│   └── trenna.db             ← banco de dados (gerado ao rodar; não vai pro Git)
├── scripts/
│   ├── seed-products.js      ← importa o catálogo para o banco
│   └── create-admin.js       ← cria a primeira conta de administrador
├── package.json              ← sem dependências
└── .env.example
```

### Duas "frentes" no mesmo site

- **`public/index.html`** (site público): preservei a página institucional + catálogo + carrinho que já existiam, para quem só quer navegar e pedir um orçamento sem criar conta (fluxo antigo, por e-mail — continua funcionando exatamente como antes).
- **`dashboard-*.html`** (sistema novo, com login): é onde vive tudo que foi pedido neste prompt — login por papel, cadastro de clientes pelo vendedor, desconto de primeira compra/atribuído calculado no servidor, histórico de pedidos de verdade, painel administrativo completo.

Não fundi as duas coisas numa SPA única de propósito: o catálogo público precisa continuar rápido e indexável pelo Google; o sistema logado é uma aplicação com estado, melhor servida separadamente. Um link **"Entrar"** no cabeçalho do site público leva ao login.

---

## 2. Papéis e permissões (RBAC)

| Ação | Cliente | Vendedor | Admin |
|---|:---:|:---:|:---:|
| Ver catálogo, montar carrinho, finalizar pedido | ✅ (só os próprios) | — | — |
| Ver/editar o próprio perfil, trocar a própria senha | ✅ | ✅ | ✅ |
| Ver o próprio histórico de pedidos e desconto | ✅ | — | — |
| Cadastrar clientes | — | ✅ (vinculados a si) | ✅ (qualquer vínculo) |
| Definir desconto de um cliente | — | ✅ (até o próprio limite) | ✅ (sem limite) |
| Ver pedidos | só os próprios | só dos seus clientes | todos |
| Gerenciar produtos (preço, estoque, disponibilidade) | — | — | ✅ |
| Criar/desativar contas, resetar senha de qualquer um | — | — | ✅ |
| Reatribuir cliente a outro vendedor | — | — | ✅ |
| Definir limite de desconto dos vendedores | — | — | ✅ |
| Ver log de auditoria | — | — | ✅ |

Tudo isso é checado **no servidor** (`server/lib/middleware.js`, função `requireAuth(role)`), nunca só escondendo botões no HTML — testei explicitamente que um cliente autenticado recebe `403 Forbidden` ao chamar uma rota de admin, e que uma chamada sem login recebe `401` (ver seção 10).

---

## 3. Sistema de desconto — regras implementadas

- **Primeira compra:** todo cliente novo recebe automaticamente o desconto configurado em "Configurações" (padrão 5%) no primeiro pedido — sem código promocional.
- **Trava contra duplicidade:** o campo `first_purchase_used` é marcado **na mesma transação de banco** que cria o pedido (`BEGIN IMMEDIATE`, que trava a escrita). Testei duas compras seguidas da mesma conta: a primeira ganhou 5%, a segunda não ganhou desconto nenhum (até o vendedor atribuir um) — ver seção 10.
- **Compras seguintes:** usam o percentual que o vendedor (ou admin) atribuiu ao cliente, respeitando o teto do vendedor (testei: vendedor com limite de 15% tentando dar 50% é bloqueado com `403`).
- **Pedido cancelado:** cancelar um pedido **não** devolve automaticamente a elegibilidade de primeira compra (evita um cliente criar/cancelar pedidos repetidamente só para "testar" o desconto). Se for um cancelamento por erro do sistema (não culpa do cliente), o administrador pode reabrir manualmente pelo painel ("Reabrir 1ª compra") — ação sempre registrada na auditoria.
- **Imutabilidade histórica:** o percentual e o valor do desconto são gravados no pedido no momento da criação. Mudar o desconto do cliente depois não altera pedidos antigos.
- **Produto sem preço:** o catálogo de origem da Trenna é atacado/B2B e não publica preço público. Um pedido com item sem preço cadastrado vira automaticamente um **pedido de orçamento** (sem total calculado, sem desconto automático) — o vendedor cotação depois. Isso está testado e funcionando (seção 10).

---

## 4. Instalação e execução local

Requer **Node.js 22.5 ou mais recente** (para o módulo nativo `node:sqlite`). Sem `npm install` — não há dependências.

```bash
# 1. Rodar as migrações (cria o banco de dados vazio)
npm run migrate

# 2. Importar o catálogo de produtos (4.530 itens + fotos)
npm run seed

# 3. Criar a primeira conta de administrador (NUNCA fica hardcoded no código)
ADMIN_NAME="Seu Nome" ADMIN_EMAIL="voce@trenna.com.br" ADMIN_PASSWORD="umaSenhaForteComMaisDe10Caracteres" npm run create-admin

# 4. Subir o servidor
npm start
# Acesse http://localhost:3000
```

Use `npm run dev` em vez de `npm start` durante o desenvolvimento (reinicia sozinho a cada alteração, via `node --watch`).

## 5. Variáveis de ambiente

Veja `.env.example`. Resumo:

| Variável | Obrigatória? | Para quê |
|---|---|---|
| `PORT` | não (padrão 3000) | porta do servidor |
| `APP_URL` | recomendada em produção | usada para montar links em e-mails |
| `DATABASE_FILE` | não (padrão `data/trenna.db`) | caminho do arquivo do banco — aponte para um disco persistente no host escolhido |
| `RESEND_API_KEY` | não | ver seção 8 — sem isso, e-mails só aparecem no log |
| `MAIL_FROM` | não | remetente dos e-mails |

Em produção, defina essas variáveis no painel do seu host (Render/Railway/Fly têm uma seção "Environment" própria) — nunca num arquivo `.env` commitado.

## 6. Criando o administrador em produção

Mesma ideia do passo 3 acima, rodado uma vez no servidor de produção (via SSH, ou o "shell"/"console" que praticamente todo host com suporte a Node oferece):

```bash
ADMIN_NAME="..." ADMIN_EMAIL="..." ADMIN_PASSWORD="..." node scripts/create-admin.js
```

A senha nunca é salva em texto puro em lugar nenhum — só o hash scrypt dela vai para o banco.

## 7. Hospedagem

**Atenção: isso mudou em relação à entrega anterior.** O site anterior (sem login) era puramente estático e cabia em GitHub Pages/Netlify/Vercel estático. **Este não cabe mais** — agora há um processo Node.js com estado (sessões, banco SQLite em arquivo) que precisa ficar rodando continuamente. GitHub Pages e o plano estático de Netlify/Vercel **não conseguem rodar isso**.

| Opção | Indicada? | Observações |
|---|---|---|
| **Render** (plano gratuito/starter) | ✅ Recomendado | Web Service com Node nativo, disco persistente pago à parte (~US$ 1/GB/mês) para o arquivo `trenna.db` sobreviver a redeploys. Deploy automático via Git. |
| **Railway** | ✅ Recomendado | Similar ao Render, volumes persistentes inclusos no plano pago. Boa opção se também quiserem um Postgres gerenciado no futuro. |
| **Fly.io** | ✅ Boa opção | Suporta volumes persistentes no plano gratuito (até 3GB) — ótimo encaixe para o SQLite. Configuração um pouco mais técnica (`fly.toml`, `flyctl`). |
| **VPS (DigitalOcean, Hetzner, Contabo, etc.)** | ✅ Se já tiverem um | Controle total, mas exige configurar Node, processo em segundo plano (`pm2` ou `systemd`) e HTTPS (Certbot) manualmente. |
| **GitHub Pages** | ❌ Não serve | Só hospeda arquivos estáticos — não roda Node, não tem banco de dados. |
| **Netlify / Vercel (estático)** | ❌ Não serve como está | Rodam só front-end estático ou funções sem estado (serverless) — não sustentam um arquivo SQLite entre requisições. Dá para adaptar no futuro trocando o SQLite por um banco hospedado (ex. Turso, Neon/Postgres) e as rotas por funções serverless — é um retrabalho de arquitetura, não uma troca de um arquivo. |

**Recomendação prática:** Render ou Fly.io para começar — ambos têm camada gratuita/baixo custo com disco persistente suficiente para este projeto (o banco de dados com 4.530 produtos + pedidos ocupa poucos MB).

## 8. E-mail (recuperação de senha, convites de clientes)

Não configurei nenhum serviço de e-mail real — não tenho uma conta/chave de API da empresa para isso, e não vou inventar uma integração que não existe de verdade.

**O que já está pronto:** `server/lib/mailer.js` usa a API HTTP da [Resend](https://resend.com) (tem plano gratuito, só precisa criar a conta e pegar uma chave) se a variável `RESEND_API_KEY` estiver definida. Sem ela, o conteúdo do e-mail (incluindo o link de criação de senha) só aparece no **log do servidor** — o que é perfeitamente utilizável para testar tudo manualmente antes de ligar o envio de verdade.

Para ativar: crie uma conta na Resend, gere uma API key, defina `RESEND_API_KEY` e `MAIL_FROM` nas variáveis de ambiente do host. Nenhuma linha de código precisa mudar.

## 9. Backup e restauração do banco de dados

O banco é um único arquivo (`data/trenna.db`, mais dois arquivos auxiliares `.db-wal`/`.db-shm` enquanto o servidor está rodando).

**Backup:** copie o arquivo `.db` periodicamente (cron job simples), ex.:
```bash
cp data/trenna.db backups/trenna-$(date +%Y%m%d-%H%M).db
```
Em hosts como Render/Fly, configure isso como uma tarefa agendada (cron job) apontando para o volume persistente.

**Restauração:** pare o servidor, substitua `data/trenna.db` pelo arquivo de backup, suba o servidor de novo.

## 10. Testes realizados

Testei o fluxo completo via requisições HTTP reais contra o servidor rodando localmente (não é simulação nem dado em memória — é o banco SQLite de verdade sendo escrito e lido). Resultados:

| Cenário | Resultado |
|---|---|
| Admin cria vendedor → vendedor define senha pelo link → login do vendedor | ✅ |
| Vendedor cadastra cliente → cliente define senha → login do cliente | ✅ |
| 1º checkout do cliente → desconto de 5% (primeira compra) aplicado corretamente | ✅ (subtotal 324,70 → desconto 16,23 → total 308,47) |
| 2º checkout da mesma conta → **sem** repetir o desconto de primeira compra | ✅ (0% aplicado) |
| Vendedor atribui 10% ao cliente → 3º checkout aplica 10% | ✅ |
| Vendedor tenta atribuir 50% com limite de 15% → bloqueado | ✅ (`403`) |
| Checkout com produto sem preço cadastrado → vira pedido de orçamento | ✅ |
| Cliente autenticado chama rota de admin → bloqueado | ✅ (`403`) |
| Requisição sem login chama rota de vendedor → bloqueado | ✅ (`401`) |
| POST sem token CSRF → bloqueado | ✅ (`403`) |
| 9 tentativas de login errado seguidas → bloqueado na 9ª | ✅ (`429`), e a senha certa também fica bloqueada até passar a janela |
| Admin muda status de um pedido → aparece no log de auditoria | ✅ |

Um bug real foi encontrado e corrigido durante esse processo: o rate limiter usava aspas duplas em SQL (`datetime("now")`), que o SQLite interpreta como nome de coluna, não como string — causava erro 500 em vez de aplicar o limite. Corrigido para aspas simples (`datetime('now')`) e reconfirmado com os mesmos testes.

**O que não testei:** carga/concorrência real com múltiplas requisições simultâneas de verdade (o teste de corrida do desconto de 1ª compra é garantido pelo design da transação `BEGIN IMMEDIATE`, que serializa escritas no SQLite, mas não executei um teste de concorrência real com requisições paralelas). Também não testei em navegadores de verdade (os testes foram via `curl`, direto na API) — os formulários HTML foram escritos e revisados, mas não clicados manualmente num navegador.

## 11. Segurança — o que foi implementado

- Senhas com **scrypt** (`node:crypto`, parâmetros N=16384/r=8/p=1 — acima do mínimo recomendado pela OWASP), nunca texto puro, comparação em tempo constante.
- Sessão via cookie `HttpOnly` + registro revogável no banco (logout de verdade, não só apagar cookie).
- CSRF via *double-submit cookie* (token exigido no header `X-CSRF-Token` em todo POST/PUT/DELETE).
- Autorização checada no servidor em toda rota sensível (RBAC real, não só esconder botão no front).
- Validação de entrada em todas as rotas (quantidade, e-mail duplicado, percentual de desconto 0–100, status de pedido dentro de uma lista fixa).
- Proteção contra SQL injection: **100% das queries usam parâmetros `?`** (`node:sqlite` prepared statements) — nunca concatenação de string.
- Content-Security-Policy, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy em toda resposta (`server/lib/middleware.js`).
- Rate limiting (login e recuperação de senha), persistido no banco — sobrevive a reinício do processo.
- Log de auditoria para: criação/edição de contas, mudança de desconto, criação de pedido, mudança de status, reset forçado de senha, reabertura de elegibilidade de 1ª compra.
- Convite de cliente/funcionário por link de criação de senha (nunca uma senha provisória comunicada em texto) — expira em 72h; recuperação de senha expira em 1h.

### LGPD — o que isso significa na prática aqui
Os dados pessoais coletados (nome, e-mail, telefone, CPF/CNPJ) ficam no banco local, acessíveis só por usuários autenticados com o papel adequado (um vendedor só vê os próprios clientes). Não há compartilhamento com terceiros no código. **Isso não substitui uma política de privacidade publicada no site, nem um mapeamento formal de dados (RIPD) — essas são decisões/documentos que a empresa precisa produzir, não algo que o código resolve sozinho.**

## 12. O que NÃO foi inventado (de propósito)

Conforme pedido explicitamente — nenhuma destas integrações foi simulada ou fingida:
- **Gateway de pagamento:** não existe. O checkout calcula e grava o total/desconto corretamente, mas "finalizar pedido" cria um pedido com status `pending_confirmation` — não cobra cartão nem PIX. O ponto de integração (se decidirem usar Stripe/Mercado Pago/PagSeguro) é a função `createOrder` em `server/lib/discount.js`.
- **Envio de e-mail real:** precisa da conta Resend (ou outro provedor) — ver seção 8.
- **Sincronização de estoque com ERP:** o campo `stock` existe na tabela `products` e é respeitado no checkout (bloqueia pedido se a quantidade pedida for maior que o estoque cadastrado), mas **ninguém está alimentando esse número automaticamente** — hoje é só o que o admin digitar manualmente no painel.
- **Preços reais da maioria dos produtos:** só 6 produtos de exemplo têm preço (marcados como demonstração no `seed-products.js`, claramente avisado no console ao rodar). Os outros 4.524 continuam "sob consulta" até o admin cadastrar o preço real pelo painel.

## 13. Tema Outubro Rosa

Troquei o rosa como cor primária (`--primary`/`--gold` no CSS), mantendo o **azul da marca como cor secundária** (variável `--blue`, ainda usada no logotipo). Fundo e superfícies passaram para tons claros/brancos, conforme pedido ("retain readability"). Criei também uma variante escura (`prefers-color-scheme: dark`) para quem usa o navegador no modo escuro — mantendo contraste adequado.

---

## Acesso de teste (ambiente local, dados de exemplo — apague antes de produção)

Depois de rodar os passos da seção 4, você terá:
- **Admin:** o e-mail/senha que você definiu no `create-admin`.
- Use o painel do admin para criar vendedores e, pelo painel do vendedor, cadastrar clientes — ou cadastre tudo direto pela seção "Usuários" do admin.

## Contato

**Trenna Distribuição**
R. Londres, 1595 — Tibery, Uberlândia - MG
(34) 3216-9574 · trenna@trenna.com.br
