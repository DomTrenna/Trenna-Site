/**
 * api.js — helper mínimo para chamar a API própria, sempre incluindo o
 * token CSRF (double-submit cookie) nos métodos que alteram dados.
 */
window.TrennaAPI = (function () {
  let csrfToken = null;

  async function ensureCsrf() {
    if (csrfToken) return csrfToken;
    const r = await fetch('/api/auth/csrf', { credentials: 'same-origin' });
    const data = await r.json();
    csrfToken = data.csrfToken;
    return csrfToken;
  }

  async function call(method, path, body) {
    const opts = { method, credentials: 'same-origin', headers: {} };
    if (method !== 'GET') {
      await ensureCsrf();
      opts.headers['X-CSRF-Token'] = csrfToken;
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body || {});
    }
    const res = await fetch(path, opts);
    let data = {};
    try { data = await res.json(); } catch (e) { /* resposta vazia */ }
    if (!res.ok) throw new Error(data.error || ('Erro ' + res.status));
    return data;
  }

  return {
    get: (path) => call('GET', path),
    post: (path, body) => call('POST', path, body),
    put: (path, body) => call('PUT', path, body),
    del: (path) => call('DELETE', path)
  };
})();
