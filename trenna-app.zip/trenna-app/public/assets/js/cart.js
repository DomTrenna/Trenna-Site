/**
 * cart.js
 * Carrinho de pedidos. Estado mantido em memória + persistido em
 * localStorage (chave "trenna_cart") para sobreviver a atualizações de página.
 *
 * IMPORTANTE — sobre preços: o catálogo de origem da Trenna é um catálogo
 * de atacado (B2B) e não lista preços — o valor é sempre combinado com o
 * vendedor. Por isso este carrinho NÃO exibe nem calcula subtotal em R$.
 * Ele existe para o cliente montar a lista de itens desejados e enviá-la
 * para o time comercial confirmar valor e prazo. Se no futuro os produtos
 * passarem a ter preço (campo "price" em products.json), o cálculo de
 * subtotal pode ser reativado em `renderCart()` (ver comentário abaixo).
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'trenna_cart';
  var EMAIL_DESTINO = 'trenna@trenna.com.br';

  var cart = loadCart();

  function loadCart() {
    try {
      return JSON.parse(window.localStorage.getItem(STORAGE_KEY) || '{}');
    } catch (e) {
      return {};
    }
  }

  function persist() {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    } catch (e) {
      /* quota excedida ou modo privado: carrinho continua funcionando em memória */
    }
  }

  function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str || '';
    return d.innerHTML;
  }

  function totalQty() {
    return Object.keys(cart).reduce(function (sum, k) { return sum + cart[k]; }, 0);
  }

  function renderCart() {
    var body = document.getElementById('cartBody');
    var foot = document.getElementById('cartFoot');
    var emptyMsg = document.getElementById('cartEmptyMsg');
    var badge = document.getElementById('cartBadge');
    if (!body) return;

    var codes = Object.keys(cart).filter(function (k) { return cart[k] > 0; });

    if (codes.length === 0) {
      body.innerHTML = '<p class="cart-empty" id="cartEmptyMsg">Seu carrinho está vazio. Adicione produtos no catálogo.</p>';
      foot.style.display = 'none';
      badge.style.display = 'none';
      return;
    }

    foot.style.display = 'block';
    body.innerHTML = codes.map(function (code) {
      var p = window.TrennaCatalog ? window.TrennaCatalog.getProduct(code) : null;
      if (!p) return '';
      var qty = cart[code];
      var img = p.img
        ? '<img src="' + p.img + '" alt="" loading="lazy" width="44" height="44">'
        : '<div class="cr-mark">' + escapeHtml((p.department || '?').slice(0, 2).toUpperCase()) + '</div>';
      return (
        '<div class="cart-item">' + img +
        '<div style="flex:1">' +
        '<div class="ci-name">' + escapeHtml(p.name) + '</div>' +
        '<div class="ci-code">' + escapeHtml(p.brand) + ' · Cód. ' + p.code + '</div>' +
        '<div class="qty-stepper" style="margin-top:6px">' +
        '<button type="button" class="ci-qty-btn" data-code="' + code + '" data-delta="-1" aria-label="Diminuir quantidade">-</button>' +
        '<span>' + qty + '</span>' +
        '<button type="button" class="ci-qty-btn" data-code="' + code + '" data-delta="1" aria-label="Aumentar quantidade">+</button>' +
        '</div>' +
        '<button type="button" class="ci-remove" data-code="' + code + '">remover</button>' +
        '</div></div>'
      );
    }).join('');

    badge.style.display = 'flex';
    badge.textContent = String(totalQty());

    body.querySelectorAll('.ci-qty-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var code = btn.getAttribute('data-code');
        var delta = parseInt(btn.getAttribute('data-delta'), 10);
        add(code, delta);
      });
    });
    body.querySelectorAll('.ci-remove').forEach(function (btn) {
      btn.addEventListener('click', function () {
        remove(btn.getAttribute('data-code'));
      });
    });
  }

  function add(code, qty) {
    var next = (cart[code] || 0) + qty;
    if (next <= 0) { delete cart[code]; } else { cart[code] = next; }
    persist();
    renderCart();
    openCart();
  }

  function remove(code) {
    delete cart[code];
    persist();
    renderCart();
  }

  function clear() {
    cart = {};
    persist();
    renderCart();
  }

  function openCart() {
    var overlay = document.getElementById('cartOverlay');
    var panel = document.getElementById('cartPanel');
    if (overlay) overlay.classList.add('open');
    if (panel) panel.classList.add('open');
  }
  function closeCart() {
    var overlay = document.getElementById('cartOverlay');
    var panel = document.getElementById('cartPanel');
    if (overlay) overlay.classList.remove('open');
    if (panel) panel.classList.remove('open');
  }

  async function submitOrder() {
    var checkoutMsg = document.getElementById('checkoutMsg');
    var codes = Object.keys(cart).filter(function (k) { return cart[k] > 0; });
    var name = (document.getElementById('ckName') || {}).value || '';
    var contact = (document.getElementById('ckContact') || {}).value || '';
    var deliveryInput = document.querySelector('input[name="delivery"]:checked');
    var delivery = deliveryInput ? deliveryInput.value : '';

    name = name.trim(); contact = contact.trim();

    if (codes.length === 0) { checkoutMsg.textContent = 'Seu carrinho está vazio.'; return; }
    if (!name || !contact) { checkoutMsg.textContent = 'Informe seu nome e um telefone ou e-mail para contato.'; return; }

    var items = codes.map(function (code) {
      var p = window.TrennaCatalog.getProduct(code);
      return { code: code, name: p ? p.name : code, brand: p ? p.brand : '', qty: cart[code] };
    });

    checkoutMsg.textContent = 'Enviando...';
    try {
      await window.TrennaStorage.saveOrder({
        items: items, delivery: delivery, customerName: name, customerContact: contact
      });

      var bodyLines = items.map(function (i) {
        return '- ' + i.name + ' (' + i.brand + ', cód. ' + i.code + ') x' + i.qty;
      }).join('%0D%0A');
      var mailBody = 'Novo pedido pelo site%0D%0A%0D%0ACliente: ' + encodeURIComponent(name) +
        '%0D%0AContato: ' + encodeURIComponent(contact) +
        '%0D%0AEntrega: ' + encodeURIComponent(delivery) +
        '%0D%0A%0D%0AItens:%0D%0A' + bodyLines;
      var mailLink = 'mailto:' + EMAIL_DESTINO + '?subject=Novo%20pedido%20pelo%20site&body=' + mailBody;

      checkoutMsg.innerHTML = 'Pedido enviado! Nosso time comercial vai entrar em contato para confirmar valor e prazo. ' +
        '<a href="' + mailLink + '">Enviar também por e-mail →</a>';
      clear();
      document.dispatchEvent(new CustomEvent('trenna:order-submitted'));
    } catch (err) {
      checkoutMsg.textContent = 'Não foi possível enviar agora — tente novamente em instantes.';
    }
  }

  function wire() {
    var openBtn = document.getElementById('cartOpenBtn');
    var closeBtn = document.getElementById('cartCloseBtn');
    var overlay = document.getElementById('cartOverlay');
    var submitBtn = document.getElementById('cartSubmitBtn');
    var clearBtn = document.getElementById('cartClearBtn');

    if (openBtn) openBtn.addEventListener('click', openCart);
    if (closeBtn) closeBtn.addEventListener('click', closeCart);
    if (overlay) overlay.addEventListener('click', closeCart);
    if (submitBtn) submitBtn.addEventListener('click', submitOrder);
    if (clearBtn) clearBtn.addEventListener('click', function () {
      if (confirm('Esvaziar o carrinho?')) clear();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeCart();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    wire();
    renderCart();
  });
  document.addEventListener('trenna:catalog-ready', renderCart);

  window.TrennaCart = { add: add, remove: remove, clear: clear, open: openCart, close: closeCart, submit: submitOrder };
})();
