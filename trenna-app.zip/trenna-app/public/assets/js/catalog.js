/**
 * catalog.js
 * Carrega data/products.json + data/product-images.json, e implementa
 * busca, filtro por departamento, ordenação, paginação incremental,
 * overlay de especificações ao passar o mouse (com equivalente por toque)
 * e o botão de adicionar ao carrinho.
 */
(function () {
  'use strict';

  var state = {
    products: [],       // lista completa {code,name,brand,variant,department,img,available}
    filtered: [],
    limit: 30,
    sort: 'relevance',
    query: '',
    department: ''
  };

  function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str || '';
    return d.innerHTML;
  }

  async function loadData() {
    var base = document.body.getAttribute('data-base') || '.';
    var [productsRes, imagesRes] = await Promise.all([
      fetch(base + '/data/products.json'),
      fetch(base + '/data/product-images.json')
    ]);
    var products = await productsRes.json();
    var imageMap = await imagesRes.json();

    state.products = products.map(function (p) {
      var img = imageMap[p.c] ? (base + '/assets/images/products/' + imageMap[p.c]) : '';
      return {
        code: p.c,
        name: p.n,
        brand: p.b,
        variant: p.v,
        department: p.d,
        img: img,
        // Sem dados reais de estoque no catálogo de origem: por padrão os itens
        // são tratados como disponíveis. Para ativar o selo "indisponível",
        // adicione "available": false ao item correspondente em products.json.
        available: p.available !== false
      };
    });
    state.filtered = state.products.slice();
    return state.products;
  }

  function populateDepartmentFilter() {
    var sel = document.getElementById('catDeptFilter');
    if (!sel) return;
    var deps = Array.from(new Set(state.products.map(function (p) { return p.department; }))).sort();
    deps.forEach(function (d) {
      var o = document.createElement('option');
      o.value = d; o.textContent = d;
      sel.appendChild(o);
    });
  }

  function applyFilters() {
    var q = state.query.trim().toLowerCase();
    var list = state.products.filter(function (p) {
      if (state.department && p.department !== state.department) return false;
      if (!q) return true;
      return p.name.toLowerCase().indexOf(q) !== -1 ||
        p.brand.toLowerCase().indexOf(q) !== -1 ||
        p.code.indexOf(q) !== -1;
    });
    if (state.sort === 'name-asc') list.sort(function (a, b) { return a.name.localeCompare(b.name); });
    else if (state.sort === 'name-desc') list.sort(function (a, b) { return b.name.localeCompare(a.name); });
    else if (state.sort === 'department') list.sort(function (a, b) { return a.department.localeCompare(b.department) || a.name.localeCompare(b.name); });
    state.filtered = list;
  }

  function specLines(p) {
    var lines = ['Código: ' + p.code];
    if (p.brand) lines.push('Marca: ' + p.brand);
    if (p.variant) lines.push('Espec.: ' + p.variant);
    lines.push('Categoria: ' + p.department);
    return lines;
  }

  function productCardHtml(p) {
    var thumb = p.img
      ? '<img class="cr-thumb" src="' + p.img + '" alt="' + escapeHtml(p.name) + '" loading="lazy" decoding="async" width="34" height="34">'
      : '<div class="cr-mark" aria-hidden="true">' + escapeHtml((p.department || '?').slice(0, 2).toUpperCase()) + '</div>';

    var overlay = '<div class="spec-overlay" role="tooltip">' +
      specLines(p).map(function (l) { return '<span>' + escapeHtml(l) + '</span>'; }).join('') +
      '</div>';

    var unavailable = !p.available ? '<span class="unavailable-badge">Indisponível</span>' : '';

    return (
      '<div class="catalog-row' + (!p.available ? ' is-unavailable' : '') + '">' +
      '<div class="cr-media" tabindex="0" aria-label="Ver especificações de ' + escapeHtml(p.name) + '">' +
      thumb + overlay +
      '</div>' +
      '<div class="cr-info"><div class="cr-name">' + escapeHtml(p.name) + unavailable + '</div>' +
      '<div class="cr-meta">' + escapeHtml(p.brand) + ' · Cód. ' + p.code + ' · ' + escapeHtml(p.department) +
      (p.variant ? ' · ' + escapeHtml(p.variant) : '') + '</div></div>' +
      '<button type="button" class="cr-add" data-code="' + p.code + '"' + (!p.available ? ' disabled' : '') + '>' +
      (p.available ? '+ Adicionar' : 'Indisponível') + '</button>' +
      '</div>'
    );
  }

  function render() {
    var results = document.getElementById('catResults');
    var count = document.getElementById('catCount');
    var loadMoreWrap = document.getElementById('catLoadMoreWrap');
    if (!results) return;

    applyFilters();
    count.textContent = state.filtered.length + ' produto(s) encontrado(s)';
    var shown = state.filtered.slice(0, state.limit);
    results.innerHTML = shown.map(productCardHtml).join('');
    loadMoreWrap.style.display = state.filtered.length > state.limit ? 'block' : 'none';

    results.querySelectorAll('.cr-add').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (btn.disabled) return;
        var code = btn.getAttribute('data-code');
        window.TrennaCart.add(code, 1);
        var original = btn.textContent;
        btn.textContent = 'Adicionado ✓';
        btn.classList.add('added');
        setTimeout(function () { btn.textContent = original; btn.classList.remove('added'); }, 1400);
      });
    });
  }

  function wireControls() {
    var searchInput = document.getElementById('catSearchInput');
    var deptFilter = document.getElementById('catDeptFilter');
    var sortSelect = document.getElementById('catSortSelect');
    var loadMoreBtn = document.getElementById('catLoadMoreBtn');

    if (searchInput) searchInput.addEventListener('input', function () {
      state.query = searchInput.value; state.limit = 30; render();
    });
    if (deptFilter) deptFilter.addEventListener('change', function () {
      state.department = deptFilter.value; state.limit = 30; render();
    });
    if (sortSelect) sortSelect.addEventListener('change', function () {
      state.sort = sortSelect.value; render();
    });
    if (loadMoreBtn) loadMoreBtn.addEventListener('click', function () {
      state.limit += 30; render();
    });

    var openBtn = document.getElementById('catalogOpenBtn');
    var overlay = document.getElementById('catalogOverlay');
    var panel = document.getElementById('catalogPanelEl');
    function openCatalog() {
      if (overlay) overlay.classList.add('open');
      if (panel) panel.classList.add('open');
      if (searchInput) searchInput.focus();
    }
    window.closeCatalog = function () {
      if (overlay) overlay.classList.remove('open');
      if (panel) panel.classList.remove('open');
    };
    if (openBtn) openBtn.addEventListener('click', openCatalog);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') window.closeCatalog();
    });
  }

  async function init() {
    try {
      await loadData();
      populateDepartmentFilter();
      wireControls();
      render();
      window.TrennaCatalog = { getProduct: function (code) { return state.products.find(function (p) { return p.code === code; }); } };
      document.dispatchEvent(new CustomEvent('trenna:catalog-ready'));
    } catch (err) {
      var results = document.getElementById('catResults');
      if (results) results.innerHTML = '<p class="cart-note">Não foi possível carregar o catálogo agora. Verifique sua conexão e recarregue a página.</p>';
      /* Erro de carregamento do catálogo é reportado ao usuário na UI acima;
         em produção, conecte um serviço de monitoramento (Sentry, etc.) aqui. */
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
