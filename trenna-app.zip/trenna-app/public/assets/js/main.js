/**
 * main.js
 * Interações gerais da página: menu mobile, animações de entrada (respeitando
 * prefers-reduced-motion), e o Painel do Vendedor (pedidos recebidos + cadastro
 * de promoções), que usa a camada de persistência em storage.js.
 */
(function () {
  'use strict';

  /* Shims de compatibilidade: o HTML usa atributos onclick="..." simples
     (mais fácil de manter/editar por quem não é programador) em vez de
     data-attributes + addEventListener em todo elemento. Estas funções
     globais fazem a ponte entre o HTML e os módulos reais (cart.js). */
  window.cartQty = function (idx, delta) {
    var el = document.getElementById('qty-' + idx);
    if (!el) return;
    var v = parseInt(el.textContent, 10) + delta;
    if (v < 1) v = 1;
    el.textContent = v;
  };
  window.addToCart = function (code, qty) { if (window.TrennaCart) window.TrennaCart.add(code, qty); };
  window.closeCart = function () { if (window.TrennaCart) window.TrennaCart.close(); };
  window.clearCart = function () { if (window.TrennaCart && confirm('Esvaziar o carrinho?')) window.TrennaCart.clear(); };
  window.submitOrder = function () { if (window.TrennaCart) window.TrennaCart.submit(); };

  function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str || '';
    return d.innerHTML;
  }
  function fmtDate(iso) {
    if (!iso) return '';
    var p = iso.split('-');
    return p[2] + '/' + p[1] + '/' + p[0];
  }
  function fmtDateTime(ts) {
    var d = new Date(ts);
    return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }
  function fmtPrice(n) {
    var v = parseFloat(n);
    return isNaN(v) ? n : v.toFixed(2).replace('.', ',');
  }

  /* ---------- Menu mobile ---------- */
  function initMenu() {
    var burger = document.querySelector('.burger');
    var menu = document.getElementById('mmenu');
    if (burger && menu) {
      burger.addEventListener('click', function () {
        var open = menu.classList.toggle('open');
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    }
  }

  /* ---------- Animações de entrada (scroll reveal) ---------- */
  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion || !('IntersectionObserver' in window)) {
      els.forEach(function (el) { el.classList.add('in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add('in'); io.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    els.forEach(function (el) { io.observe(el); });
  }

  /* ---------- Painel do Vendedor ---------- */
  var FEATURED_CODES = ['408598', '409488', '406577', '409288', '406736', '4597'];

  function initSellerPanel() {
    var toggleBtn = document.getElementById('sellerToggle');
    var wrap = document.getElementById('promoForm_wrap');
    var tabOrdersBtn = document.getElementById('tabOrdersBtn');
    var tabPromoBtn = document.getElementById('tabPromoBtn');
    var ordersTab = document.getElementById('ordersTab');
    var promoForm = document.getElementById('promoForm');
    if (!toggleBtn || !wrap) return;

    toggleBtn.addEventListener('click', function () { wrap.classList.toggle('open'); });

    function showTab(tab) {
      if (tab === 'orders') {
        ordersTab.style.display = 'block'; promoForm.style.display = 'none';
        tabOrdersBtn.classList.add('active'); tabPromoBtn.classList.remove('active');
        loadOrders();
      } else {
        ordersTab.style.display = 'none'; promoForm.style.display = 'block';
        tabOrdersBtn.classList.remove('active'); tabPromoBtn.classList.add('active');
      }
    }
    window.showSellerTab = showTab;

    /* --- pedidos --- */
    async function loadOrders() {
      var list = document.getElementById('ordersList');
      var empty = document.getElementById('ordersEmpty');
      if (!list) return;
      try {
        var orders = await window.TrennaStorage.listOrders();
        if (!orders.length) {
          empty.style.display = 'block'; list.innerHTML = ''; return;
        }
        empty.style.display = 'none';
        list.innerHTML = orders.map(function (o) {
          var itemsHtml = (o.items || []).map(function (i) {
            return '<li>' + i.qty + 'x ' + escapeHtml(i.name) + ' (' + escapeHtml(i.brand) + ', cód. ' + i.code + ')</li>';
          }).join('');
          var statuses = ['novo', 'em atendimento', 'concluído'];
          return (
            '<div class="order-card">' +
            '<div class="oc-head"><span class="oc-cust">' + escapeHtml(o.customerName || '—') + ' · ' + escapeHtml(o.customerContact || '') + '</span>' +
            '<span class="oc-when">' + fmtDateTime(o.createdAt || 0) + '</span></div>' +
            '<ul class="oc-items">' + itemsHtml + '</ul>' +
            '<div class="oc-delivery">' + escapeHtml(o.delivery || '') + '</div>' +
            '<div class="order-status"><label>Status:</label>' +
            '<select data-id="' + o._id + '">' +
            statuses.map(function (s) { return '<option value="' + s + '"' + (o.status === s ? ' selected' : '') + '>' + s + '</option>'; }).join('') +
            '</select></div></div>'
          );
        }).join('');
        list.querySelectorAll('select[data-id]').forEach(function (sel) {
          sel.addEventListener('change', function () {
            window.TrennaStorage.updateOrderStatus(sel.getAttribute('data-id'), sel.value);
          });
        });
      } catch (e) {
        empty.textContent = 'Não foi possível carregar os pedidos agora.';
        empty.style.display = 'block';
      }
    }

    /* --- promoções --- */
    var productSel = document.getElementById('promoProduct');
    var preview = document.getElementById('productPreview');

    document.addEventListener('trenna:catalog-ready', function () {
      if (!productSel || !window.TrennaCatalog) return;
      var bySegment = {};
      FEATURED_CODES.forEach(function (code) {
        var p = window.TrennaCatalog.getProduct(code);
        if (!p) return;
        (bySegment[p.department] = bySegment[p.department] || []).push(p);
      });
      Object.keys(bySegment).forEach(function (seg) {
        var og = document.createElement('optgroup'); og.label = seg;
        bySegment[seg].forEach(function (p) {
          var o = document.createElement('option'); o.value = p.code; o.textContent = p.name + ' — ' + p.brand;
          og.appendChild(o);
        });
        productSel.appendChild(og);
      });
      loadPromos();
    });

    if (productSel) productSel.addEventListener('change', function () {
      var p = window.TrennaCatalog.getProduct(productSel.value);
      if (!p) { preview.innerHTML = '<span class="muted-note">Selecione um produto para ver os detalhes</span>'; return; }
      var img = p.img ? '<img src="' + p.img + '" alt="">' : '';
      preview.innerHTML = img + '<div class="pp-text"><b>' + escapeHtml(p.department) + '</b><small>' + escapeHtml(p.brand) + ' · Cód. ' + p.code + '</small></div>';
    });

    async function loadPromos() {
      var list = document.getElementById('promoList');
      var empty = document.getElementById('promoEmpty');
      if (!list) return;
      try {
        var promos = await window.TrennaStorage.listPromos();
        var today = new Date().toISOString().slice(0, 10);
        var active = promos.filter(function (p) { return p.validUntil >= today; })
          .sort(function (a, b) { return a.validUntil.localeCompare(b.validUntil); });
        if (!active.length) { empty.style.display = 'block'; list.innerHTML = ''; return; }
        empty.style.display = 'none';
        list.innerHTML = active.map(function (p) {
          var oldPrice = p.priceFrom ? '<span class="old">De R$ ' + fmtPrice(p.priceFrom) + '</span>' : '';
          var thumb = p.img ? '<div class="promo-thumb"><img src="' + p.img + '" alt=""></div>' : '';
          return thumb + '<div class="promo-body"><span class="badge">Oferta</span>' +
            '<h3>' + escapeHtml(p.product) + '</h3>' +
            '<span class="seg-tag">' + escapeHtml(p.segment) + ' · ' + escapeHtml(p.brand || '') + '</span>' +
            '<div class="promo-price">' + oldPrice + 'R$ ' + fmtPrice(p.price) + '</div>' +
            '<div class="promo-until">Válido até ' + fmtDate(p.validUntil) + '</div></div>';
        }).map(function (html) { return '<div class="promo-card">' + html + '</div>'; }).join('');
      } catch (e) {
        empty.textContent = 'Não foi possível carregar as promoções agora.';
        empty.style.display = 'block';
      }
    }

    if (promoForm) promoForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      var formMsg = document.getElementById('formMsg');
      var p = window.TrennaCatalog.getProduct(productSel.value);
      var price = document.getElementById('promoPrice').value;
      var priceFrom = document.getElementById('promoPriceFrom').value;
      var validUntil = document.getElementById('promoDate').value;
      if (!p || !price || !validUntil) { formMsg.textContent = 'Selecione o produto, o preço e a data de validade.'; return; }
      formMsg.textContent = 'Salvando...';
      try {
        await window.TrennaStorage.savePromo({
          segment: p.department, brand: p.brand, product: p.name, code: p.code, img: p.img,
          price: price, priceFrom: priceFrom || null, validUntil: validUntil
        });
        formMsg.textContent = 'Promoção publicada!';
        promoForm.reset();
        preview.innerHTML = '<span class="muted-note">Selecione um produto para ver os detalhes</span>';
        loadPromos();
        setTimeout(function () { formMsg.textContent = ''; }, 2500);
      } catch (err) {
        formMsg.textContent = 'Não foi possível salvar — tente novamente.';
      }
    });

    document.addEventListener('trenna:order-submitted', function () {
      if (ordersTab.style.display !== 'none') loadOrders();
    });
  }

  /* Overlay de especificações ao toque, em qualquer imagem de produto da
     página (funciona junto com :hover/:focus-within no CSS para mouse e
     teclado — este listener cobre telas touch, via delegação de evento
     para funcionar também em cards adicionados dinamicamente). */
  function initSpecTouch() {
    document.addEventListener('click', function (e) {
      var media = e.target.closest('.cr-media');
      if (media) { media.classList.toggle('touched'); return; }
      if (!e.target.closest('.spec-overlay')) {
        document.querySelectorAll('.cr-media.touched').forEach(function (el) {
          el.classList.remove('touched');
        });
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initMenu();
    initReveal();
    initSellerPanel();
    initSpecTouch();
  });

  /* PWA opcional: registra o service worker só em produção (http/https),
     nunca em file:// (onde Service Worker não é suportado) e sem quebrar
     o site caso o navegador não suporte a API. */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('./service-worker.js').catch(function () {
        /* Registro falhou (ex.: hospedagem sem HTTPS) — site continua funcionando normalmente sem PWA. */
      });
    });
  }
})();
