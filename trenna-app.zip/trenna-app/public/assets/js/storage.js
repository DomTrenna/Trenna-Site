/**
 * storage.js
 * Camada de persistência do site.
 *
 * Por que existe: o protótipo original rodava dentro do ambiente de Artifacts
 * do Claude, que oferece uma API de banco de dados (`window.claude.use('db')`)
 * exclusiva daquele ambiente. Em produção (GitHub Pages, Netlify, Vercel,
 * cPanel, VPS...) essa API não existe.
 *
 * Este módulo resolve isso com um adaptador: se `window.claude` existir, usa
 * o banco do Claude; caso contrário, usa `localStorage` do navegador (o que
 * mantém o site 100% funcional em qualquer host, com a ressalva de que os
 * dados ficam salvos só no navegador de quem preencheu o formulário — não são
 * compartilhados entre visitantes).
 *
 * PARA INTEGRAR UM BACKEND REAL (recomendado em produção):
 * Troque a implementação de `LocalAdapter` abaixo por chamadas `fetch()`
 * para a sua API (por exemplo `POST /api/orders`, `GET /api/orders`).
 * A interface pública (TrennaStorage.saveOrder, .listOrders, etc.) não
 * precisa mudar — só o adaptador por trás dela.
 */
(function (window) {
  'use strict';

  function uid(prefix) {
    return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  }

  /* ---------- Adaptador: localStorage (funciona em qualquer host) ---------- */
  var LocalAdapter = {
    _read: function (key) {
      try {
        return JSON.parse(window.localStorage.getItem(key) || '{}');
      } catch (e) {
        return {};
      }
    },
    _write: function (key, obj) {
      try {
        window.localStorage.setItem(key, JSON.stringify(obj));
      } catch (e) {
        /* localStorage indisponível (modo privado, quota etc.) — falha silenciosa */
      }
    },
    set: function (collection, id, data) {
      var all = this._read(collection);
      all[id] = data;
      this._write(collection, all);
      return Promise.resolve(data);
    },
    update: function (collection, id, patch) {
      var all = this._read(collection);
      all[id] = Object.assign({}, all[id] || {}, patch);
      this._write(collection, all);
      return Promise.resolve(all[id]);
    },
    list: function (collection) {
      var all = this._read(collection);
      return Promise.resolve(Object.keys(all).map(function (id) {
        return Object.assign({ _id: id }, all[id]);
      }));
    }
  };

  /* ---------- Adaptador: Claude Artifacts (preview dentro do Claude) ---------- */
  var ClaudeAdapter = {
    _db: null,
    _ready: null,
    _init: function () {
      if (!this._ready) {
        this._ready = window.claude.use('db').then(function (db) {
          ClaudeAdapter._db = db;
          return db;
        }).catch(function () {
          return null;
        });
      }
      return this._ready;
    },
    set: function (collection, id, data) {
      return this._init().then(function (db) {
        if (!db) return LocalAdapter.set(collection, id, data);
        return db.doc(collection + '/' + id).set(data).then(function () { return data; });
      });
    },
    update: function (collection, id, patch) {
      return this._init().then(function (db) {
        if (!db) return LocalAdapter.update(collection, id, patch);
        return db.doc(collection + '/' + id).update(patch);
      });
    },
    list: function (collection) {
      return this._init().then(function (db) {
        if (!db) return LocalAdapter.list(collection);
        return db.collection(collection).get().then(function (snap) {
          return (snap.docs || []).map(function (d) {
            return Object.assign({ _id: d.id }, d.data());
          });
        });
      });
    }
  };

  var adapter = (typeof window.claude !== 'undefined' && window.claude && window.claude.use)
    ? ClaudeAdapter
    : LocalAdapter;

  window.TrennaStorage = {
    /** Salva um novo pedido. Retorna o pedido salvo (com data/hora). */
    saveOrder: function (order) {
      var id = uid('ord');
      order.status = order.status || 'novo';
      order.createdAt = Date.now();
      return adapter.set('orders', id, order);
    },
    /** Lista todos os pedidos, mais recentes primeiro. */
    listOrders: function () {
      return adapter.list('orders').then(function (list) {
        return list.sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });
      });
    },
    updateOrderStatus: function (id, status) {
      return adapter.update('orders', id, { status: status });
    },
    savePromo: function (promo) {
      var id = uid('promo');
      promo.createdAt = Date.now();
      return adapter.set('promos', id, promo);
    },
    listPromos: function () {
      return adapter.list('promos');
    },
    /** true quando os dados são compartilhados entre visitantes (Claude); false quando é só localStorage local. */
    isShared: function () {
      return adapter === ClaudeAdapter;
    }
  };
})(window);
