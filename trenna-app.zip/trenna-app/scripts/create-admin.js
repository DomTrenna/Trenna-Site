// scripts/create-admin.js
//
// Cria a PRIMEIRA conta de administrador do sistema.
//
// Por segurança, NÃO existe um admin padrão/hardcoded em lugar nenhum do
// código — isso seria uma porta dos fundos óbvia. Você fornece o e-mail e a
// senha por variáveis de ambiente, só nesta execução única:
//
//   ADMIN_NAME="Seu Nome" ADMIN_EMAIL="voce@trenna.com.br" ADMIN_PASSWORD="umaSenhaForte123" node scripts/create-admin.js
//
// A senha nunca fica salva em nenhum arquivo — só o hash dela vai para o
// banco de dados. Troque a senha pelo próprio painel assim que entrar.
'use strict';
const db = require('../server/db');
const { hashPassword } = require('../server/lib/password');

db.migrate();

const name = process.env.ADMIN_NAME;
const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD;

if (!name || !email || !password) {
  console.error('Uso: ADMIN_NAME="..." ADMIN_EMAIL="..." ADMIN_PASSWORD="..." node scripts/create-admin.js');
  process.exit(1);
}
if (password.length < 10) {
  console.error('Use uma senha de administrador com pelo menos 10 caracteres.');
  process.exit(1);
}

const existing = db.get('SELECT id FROM users WHERE email = ?', [email]);
if (existing) {
  console.error(`Já existe um usuário com o e-mail ${email}.`);
  process.exit(1);
}

const r = db.run(
  `INSERT INTO users (role, name, email, password_hash, active) VALUES ('admin', ?, ?, ?, 1)`,
  [name, email, hashPassword(password)]
);
console.log(`Administrador criado: #${r.lastInsertRowid} — ${email}`);
console.log('Troque a senha pelo painel assim que fizer o primeiro login.');
