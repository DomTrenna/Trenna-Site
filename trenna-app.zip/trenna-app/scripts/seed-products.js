// scripts/seed-products.js
// Importa data/products-source.json + data/product-images-source.json (o
// catálogo real, extraído do PDF da Trenna) para dentro do banco de dados.
// Rode com: node scripts/seed-products.js
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const db = require('../server/db');

db.migrate();

const products = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'products-source.json'), 'utf8'));
const imageMap = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'product-images-source.json'), 'utf8'));

// Nenhum preço real existe na origem (catálogo de atacado não publica
// preço). Para você conseguir TESTAR o fluxo de checkout de ponta a ponta,
// este script marca alguns produtos de exemplo com preço de demonstração —
// claramente avisado no console. Troque/esvazie como quiser pelo painel
// administrativo (Produtos) depois.
const DEMO_PRICED_CODES = {
  '408598': 149.9, '409488': 89.9, '406577': 24.9,
  '409288': 32.5, '406736': 28.9, '4597': 45.0
};

const insert = `INSERT INTO products (code, name, brand, variant, department, image, price, stock, available)
  VALUES (@code,@name,@brand,@variant,@department,@image,@price,@stock,@available)
  ON CONFLICT(code) DO UPDATE SET name=excluded.name, brand=excluded.brand, variant=excluded.variant,
    department=excluded.department, image=excluded.image`;

let count = 0;
db.transaction(() => {
  for (const p of products) {
    const image = imageMap[p.c] ? ('assets/images/products/' + imageMap[p.c]) : null;
    db.run(insert.replace(/@(\w+)/g, '?'), [
      p.c, p.n, p.b, p.v, p.d, image,
      DEMO_PRICED_CODES[p.c] ?? null,
      null, // estoque: não controlado por padrão
      1
    ]);
    count++;
  }
});

console.log(`[seed] ${count} produtos importados.`);
console.log(`[seed] ${Object.keys(DEMO_PRICED_CODES).length} produtos receberam preço de DEMONSTRAÇÃO (para testar o checkout): ${Object.keys(DEMO_PRICED_CODES).join(', ')}`);
console.log('[seed] Todos os demais produtos ficaram sem preço — defina pelo painel administrativo quando tiver os valores reais.');
