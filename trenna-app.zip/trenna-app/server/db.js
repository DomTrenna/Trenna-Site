// server/db.js
// Conexão com o banco de dados. Usa o módulo nativo `node:sqlite` (disponível
// a partir do Node.js 22.5+), para que o projeto rode com ZERO dependências
// de terceiros — nada de `npm install`, nada que possa quebrar por uma
// versão de pacote incompatível daqui a um ano.
//
// Se no futuro o volume de pedidos justificar um banco cliente-servidor
// (Postgres/MySQL), troque apenas este arquivo — o resto do código usa só
// os métodos exportados aqui (get/all/run/transaction).

'use strict';
const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.DATABASE_FILE || path.join(__dirname, '..', 'data', 'trenna.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

function migrate() {
  db.exec(`CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TEXT DEFAULT (datetime('now')))`);
  const dir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  const applied = new Set(db.prepare('SELECT name FROM _migrations').all().map(r => r.name));
  for (const file of files) {
    if (applied.has(file)) continue;
    const sql = fs.readFileSync(path.join(dir, file), 'utf8');
    db.exec('BEGIN');
    try {
      db.exec(sql);
      db.prepare('INSERT INTO _migrations (name) VALUES (?)').run(file);
      db.exec('COMMIT');
      console.log('[migrate] aplicada:', file);
    } catch (err) {
      db.exec('ROLLBACK');
      throw new Error(`Falha ao aplicar migração ${file}: ${err.message}`);
    }
  }
}

function get(sql, params = []) {
  return db.prepare(sql).get(...params);
}
function all(sql, params = []) {
  return db.prepare(sql).all(...params);
}
function run(sql, params = []) {
  return db.prepare(sql).run(...params);
}
/** Executa fn dentro de uma transação (BEGIN IMMEDIATE trava a escrita,
 * evitando corrida entre duas requisições simultâneas — importante para
 * o desconto de primeira compra e para checkout). */
function transaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { db, migrate, get, all, run, transaction, DB_PATH };
