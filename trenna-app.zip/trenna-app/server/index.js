// server/index.js — ponto de entrada do servidor.
'use strict';
const http = require('node:http');
const path = require('node:path');
const { Router } = require('./router');
const { serveStatic } = require('./static');
const { securityHeaders } = require('./lib/middleware');
const db = require('./db');

db.migrate();

const router = new Router();

require('./routes/auth')(router);
require('./routes/catalog')(router);
require('./routes/customer')(router);
require('./routes/rep')(router);
require('./routes/admin')(router);

const staticHandler = serveStatic(path.join(__dirname, '..', 'public'));

const server = http.createServer(async (req, res) => {
  securityHeaders(req, res, () => {});
  try {
    if (req.url.startsWith('/api/')) {
      await router.handle(req, res);
    } else {
      staticHandler(req, res, () => {
        res.statusCode = 404;
        res.end('Não encontrado.');
      });
    }
  } catch (err) {
    console.error('[erro não tratado]', err);
    if (!res.headersSent) res.statusCode = 500;
    res.end('Erro interno do servidor.');
  }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Trenna rodando em http://localhost:${PORT}`);
  console.log(`Banco de dados: ${db.DB_PATH}`);
});
