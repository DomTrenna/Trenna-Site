-- 001_init.sql — esquema inicial do banco de dados da Trenna
-- SQLite (arquivo único, via módulo nativo node:sqlite — sem dependências externas)

PRAGMA foreign_keys = ON;

-- Um único cadastro de usuários com papel (role). Simplifica autenticação
-- e permissões: o campo "role" decide o que cada um pode fazer.
CREATE TABLE IF NOT EXISTS users (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  role                 TEXT NOT NULL CHECK (role IN ('customer','rep','admin')),
  name                 TEXT NOT NULL,
  email                TEXT NOT NULL UNIQUE,
  phone                TEXT,
  company_name         TEXT,
  tax_id               TEXT,                 -- CPF ou CNPJ
  password_hash        TEXT NOT NULL,        -- scrypt (ver server/lib/password.js)
  rep_id               INTEGER REFERENCES users(id), -- vendedor responsável (só para customer)
  discount_percent     REAL NOT NULL DEFAULT 0,       -- desconto atribuído ao cliente p/ próximas compras
  max_discount_percent REAL,                  -- limite máximo que um vendedor pode conceder (só p/ rep)
  first_purchase_used  INTEGER NOT NULL DEFAULT 0,    -- trava de desconto de 1ª compra (ver server/lib/discount.js)
  active               INTEGER NOT NULL DEFAULT 1,
  created_at           TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_rep ON users(rep_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE TABLE IF NOT EXISTS sessions (
  id          TEXT PRIMARY KEY,   -- hash do token do cookie (nunca o token em texto puro)
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS password_resets (
  token_hash  TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at  TEXT NOT NULL,
  used        INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  code        TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  brand       TEXT,
  variant     TEXT,
  department  TEXT,
  image       TEXT,
  price       REAL,                -- NULL = sem preço público definido (cotação com vendedor)
  stock       INTEGER,             -- NULL = estoque não controlado
  available   INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_products_department ON products(department);

CREATE TABLE IF NOT EXISTS orders (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id        INTEGER NOT NULL REFERENCES users(id),
  rep_id             INTEGER REFERENCES users(id),
  status             TEXT NOT NULL DEFAULT 'pending_confirmation'
                       CHECK (status IN ('pending_confirmation','confirmed','processing','dispatched','delivered','canceled')),
  subtotal           REAL NOT NULL,
  discount_percent   REAL NOT NULL DEFAULT 0,
  discount_amount    REAL NOT NULL DEFAULT 0,
  total              REAL NOT NULL,
  discount_reason    TEXT NOT NULL DEFAULT 'none' CHECK (discount_reason IN ('none','first_purchase','assigned')),
  delivery_method    TEXT,
  created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_rep ON orders(rep_id);

CREATE TABLE IF NOT EXISTS order_items (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_code  TEXT NOT NULL,
  product_name  TEXT NOT NULL,    -- snapshot: nome no momento da compra
  unit_price    REAL,             -- snapshot: preço no momento da compra
  qty           INTEGER NOT NULL CHECK (qty > 0)
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS order_status_history (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status      TEXT NOT NULL,
  changed_by  INTEGER REFERENCES users(id),
  changed_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id    INTEGER REFERENCES users(id),
  action      TEXT NOT NULL,
  target_type TEXT,
  target_id   TEXT,
  details     TEXT,               -- JSON em texto
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rate_limits (
  key          TEXT PRIMARY KEY,
  count        INTEGER NOT NULL DEFAULT 1,
  window_start TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS site_settings (
  key    TEXT PRIMARY KEY,
  value  TEXT NOT NULL
);
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('first_purchase_discount_percent', '5');
INSERT OR IGNORE INTO site_settings (key, value) VALUES ('default_rep_max_discount_percent', '10');
