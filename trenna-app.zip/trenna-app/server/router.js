// server/router.js
// Um roteador HTTP bem pequeno, feito só com módulos nativos do Node — já
// que não há acesso à internet neste ambiente para `npm install express`.
// Suporta: parâmetros de rota (:id), middlewares em cadeia, corpo JSON,
// helpers res.json()/res.status()/res.redirect().
'use strict';

class Router {
  constructor() {
    this.routes = []; // { method, pattern, keys, handlers }
  }

  _add(method, path, handlers) {
    const keys = [];
    const pattern = new RegExp('^' + path.replace(/:[^/]+/g, (m) => {
      keys.push(m.slice(1));
      return '([^/]+)';
    }) + '$');
    this.routes.push({ method, pattern, keys, handlers });
  }

  get(path, ...h) { this._add('GET', path, h); }
  post(path, ...h) { this._add('POST', path, h); }
  put(path, ...h) { this._add('PUT', path, h); }
  delete(path, ...h) { this._add('DELETE', path, h); }

  async handle(req, res) {
    const url = new URL(req.url, 'http://localhost');
    req.query = Object.fromEntries(url.searchParams);
    req.pathname = url.pathname;

    for (const route of this.routes) {
      if (route.method !== req.method) continue;
      const m = route.pattern.exec(req.pathname);
      if (!m) continue;
      req.params = {};
      route.keys.forEach((k, i) => { req.params[k] = decodeURIComponent(m[i + 1]); });

      await parseBody(req);
      decorateResponse(res);

      let i = 0;
      const next = async (err) => {
        if (err) return sendError(res, err);
        const handler = route.handlers[i++];
        if (!handler) return;
        try { await handler(req, res, next); } catch (e) { sendError(res, e); }
      };
      return next();
    }
    res.statusCode = 404;
    res.end('Not found');
  }
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    if (req.method === 'GET' || req.method === 'DELETE') { req.body = {}; return resolve(); }
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 2 * 1024 * 1024) { req.destroy(); return reject(new Error('Corpo da requisição muito grande.')); }
      chunks.push(c);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      const type = req.headers['content-type'] || '';
      try {
        if (type.includes('application/json')) req.body = raw ? JSON.parse(raw) : {};
        else if (type.includes('application/x-www-form-urlencoded')) req.body = Object.fromEntries(new URLSearchParams(raw));
        else req.body = {};
        resolve();
      } catch (e) { reject(Object.assign(new Error('JSON inválido no corpo da requisição.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function decorateResponse(res) {
  res.status = (code) => { res.statusCode = code; return res; };
  res.json = (obj) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.end(JSON.stringify(obj));
  };
  res.html = (str) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(str);
  };
  res.redirect = (location) => {
    res.statusCode = 302;
    res.setHeader('Location', location);
    res.end();
  };
}

function sendError(res, err) {
  const status = err.status || 500;
  if (status >= 500) console.error('[erro]', err);
  if (!res.headersSent) {
    res.status ? res.status(status) : (res.statusCode = status);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
  }
  res.end(JSON.stringify({ error: err.message || 'Erro interno.' }));
}

module.exports = { Router };
