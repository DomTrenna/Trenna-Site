// server/routes/admin.js
'use strict';
const db = require('../db');
const { hashPassword, randomToken, sha256 } = require('../lib/password');
const discount = require('../lib/discount');
const mailer = require('../lib/mailer');
const audit = require('../lib/audit');
const { requireAuth, requireCsrf } = require('../lib/middleware');

function publicUser(u) { const { password_hash, ...rest } = u; return rest; }

module.exports = function registerAdminRoutes(router) {
  const admin = requireAuth('admin');

  /* ---------- Usuários ---------- */
  router.get('/api/admin/users', admin, (req, res) => {
    const { role = '', q = '' } = req.query;
    let sql = 'SELECT * FROM users WHERE 1=1';
    const params = [];
    if (role) { sql += ' AND role = ?'; params.push(role); }
    if (q) { sql += ' AND (name LIKE ? OR email LIKE ?)'; const like = `%${q}%`; params.push(like, like); }
    sql += ' ORDER BY created_at DESC';
    res.json({ users: db.all(sql, params).map(publicUser) });
  });

  router.post('/api/admin/users', admin, requireCsrf, async (req, res, next) => {
    const { role, name, email, phone, companyName, taxId, maxDiscountPercent, repId } = req.body;
    if (!['customer', 'rep', 'admin'].includes(role)) return next(Object.assign(new Error('Papel inválido.'), { status: 400 }));
    if (!name || !email) return next(Object.assign(new Error('Nome e e-mail são obrigatórios.'), { status: 400 }));
    const emailNorm = String(email).trim().toLowerCase();
    if (db.get('SELECT id FROM users WHERE email = ?', [emailNorm])) {
      return next(Object.assign(new Error('Já existe um usuário com este e-mail.'), { status: 409 }));
    }
    const placeholder = hashPassword(randomToken(24));
    const r = db.run(
      `INSERT INTO users (role, name, email, phone, company_name, tax_id, password_hash, rep_id, max_discount_percent)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [role, name, emailNorm, phone || null, companyName || null, taxId || null, placeholder,
        role === 'customer' ? (repId || null) : null,
        role === 'rep' ? (maxDiscountPercent ?? parseFloat(db.get("SELECT value FROM site_settings WHERE key='default_rep_max_discount_percent'").value)) : null]
    );
    audit.log(req.user.id, 'user.created', 'user', r.lastInsertRowid, { role, email: emailNorm });

    const token = randomToken(32);
    db.run('INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?,?,?)',
      [sha256(token), r.lastInsertRowid, new Date(Date.now() + 72 * 3600000).toISOString()]);
    const link = `${process.env.APP_URL || `http://${req.headers.host}`}/reset-password.html?token=${token}`;
    try {
      await mailer.send({ to: emailNorm, subject: 'Acesso criado — Trenna Distribuição', text: `Sua conta (${role}) foi criada. Crie sua senha: ${link}` });
    } catch (e) { console.error('[mailer]', e.message); }

    res.status(201).json({ ok: true, userId: r.lastInsertRowid, setPasswordLink: link });
  });

  router.put('/api/admin/users/:id', admin, requireCsrf, (req, res, next) => {
    const user = db.get('SELECT * FROM users WHERE id = ?', [req.params.id]);
    if (!user) return next(Object.assign(new Error('Usuário não encontrado.'), { status: 404 }));
    const { name, phone, companyName, taxId, active, repId, maxDiscountPercent } = req.body;
    db.run(
      `UPDATE users SET name=COALESCE(?,name), phone=COALESCE(?,phone), company_name=COALESCE(?,company_name),
       tax_id=COALESCE(?,tax_id), active=COALESCE(?,active), rep_id=COALESCE(?,rep_id),
       max_discount_percent=COALESCE(?,max_discount_percent) WHERE id=?`,
      [name ?? null, phone ?? null, companyName ?? null, taxId ?? null,
        active === undefined ? null : (active ? 1 : 0), repId ?? null, maxDiscountPercent ?? null, user.id]
    );
    audit.log(req.user.id, 'user.updated', 'user', user.id, req.body);
    res.json({ ok: true });
  });

  // Reatribuir cliente a outro vendedor
  router.put('/api/admin/users/:id/reassign-rep', admin, requireCsrf, (req, res, next) => {
    const customer = db.get('SELECT * FROM users WHERE id = ? AND role = ?', [req.params.id, 'customer']);
    if (!customer) return next(Object.assign(new Error('Cliente não encontrado.'), { status: 404 }));
    db.run('UPDATE users SET rep_id = ? WHERE id = ?', [req.body.repId || null, customer.id]);
    audit.log(req.user.id, 'customer.reassigned', 'user', customer.id, { newRepId: req.body.repId });
    res.json({ ok: true });
  });

  // Override administrativo do desconto de um cliente (sem limite de teto de vendedor)
  router.put('/api/admin/users/:id/discount', admin, requireCsrf, (req, res, next) => {
    try {
      discount.assignDiscount({ actorId: req.user.id, actorRole: 'admin', repMax: null, customerId: req.params.id, percent: req.body.percent });
      res.json({ ok: true });
    } catch (e) { next(e); }
  });

  router.put('/api/admin/users/:id/reset-password', admin, requireCsrf, async (req, res, next) => {
    const user = db.get('SELECT * FROM users WHERE id = ?', [req.params.id]);
    if (!user) return next(Object.assign(new Error('Usuário não encontrado.'), { status: 404 }));
    const token = randomToken(32);
    db.run('INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?,?,?)',
      [sha256(token), user.id, new Date(Date.now() + 3600000).toISOString()]);
    const link = `${process.env.APP_URL || `http://${req.headers.host}`}/reset-password.html?token=${token}`;
    audit.log(req.user.id, 'user.password_reset_forced', 'user', user.id, null);
    try { await mailer.send({ to: user.email, subject: 'Redefinição de senha — Trenna', text: `Link para redefinir sua senha: ${link}` }); }
    catch (e) { console.error('[mailer]', e.message); }
    res.json({ ok: true, resetLink: link });
  });

  router.put('/api/admin/users/:id/restore-first-purchase', admin, requireCsrf, (req, res, next) => {
    const user = db.get('SELECT * FROM users WHERE id = ? AND role = ?', [req.params.id, 'customer']);
    if (!user) return next(Object.assign(new Error('Cliente não encontrado.'), { status: 404 }));
    discount.restoreFirstPurchase(req.user.id, user.id);
    res.json({ ok: true });
  });

  /* ---------- Produtos ---------- */
  router.put('/api/admin/products/:code', admin, requireCsrf, (req, res, next) => {
    const product = db.get('SELECT * FROM products WHERE code = ?', [req.params.code]);
    if (!product) return next(Object.assign(new Error('Produto não encontrado.'), { status: 404 }));
    const { price, stock, available, name, department } = req.body;
    db.run(
      `UPDATE products SET price=COALESCE(?,price), stock=COALESCE(?,stock), available=COALESCE(?,available),
       name=COALESCE(?,name), department=COALESCE(?,department) WHERE code=?`,
      [price ?? null, stock ?? null, available === undefined ? null : (available ? 1 : 0), name ?? null, department ?? null, product.code]
    );
    audit.log(req.user.id, 'product.updated', 'product', product.code, req.body);
    res.json({ ok: true });
  });

  /* ---------- Pedidos ---------- */
  router.get('/api/admin/orders', admin, (req, res) => {
    const orders = db.all(
      `SELECT o.*, c.name as customer_name, r.name as rep_name FROM orders o
       JOIN users c ON c.id = o.customer_id LEFT JOIN users r ON r.id = o.rep_id
       ORDER BY o.id DESC LIMIT 500`
    );
    res.json({ orders });
  });

  const VALID_STATUSES = ['pending_confirmation', 'confirmed', 'processing', 'dispatched', 'delivered', 'canceled'];
  router.put('/api/admin/orders/:id/status', admin, requireCsrf, (req, res, next) => {
    putOrderStatus(req, res, next, req.user);
  });

  function putOrderStatus(req, res, next, actor) {
    const { status } = req.body;
    if (!VALID_STATUSES.includes(status)) return next(Object.assign(new Error('Status inválido.'), { status: 400 }));
    const order = db.get('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!order) return next(Object.assign(new Error('Pedido não encontrado.'), { status: 404 }));
    db.transaction(() => {
      db.run('UPDATE orders SET status = ? WHERE id = ?', [status, order.id]);
      db.run('INSERT INTO order_status_history (order_id, status, changed_by) VALUES (?,?,?)', [order.id, status, actor.id]);
    });
    audit.log(actor.id, 'order.status_changed', 'order', order.id, { from: order.status, to: status });
    res.json({ ok: true });
  }

  /* ---------- Configurações do site ---------- */
  router.get('/api/admin/settings', admin, (req, res) => {
    res.json({ settings: db.all('SELECT * FROM site_settings') });
  });
  router.put('/api/admin/settings/:key', admin, requireCsrf, (req, res) => {
    db.run('INSERT INTO site_settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
      [req.params.key, String(req.body.value)]);
    audit.log(req.user.id, 'settings.updated', 'setting', req.params.key, { value: req.body.value });
    res.json({ ok: true });
  });

  /* ---------- Relatórios simples (números reais, sem gráfico) ---------- */
  router.get('/api/admin/reports/summary', admin, (req, res) => {
    const totalCustomers = db.get("SELECT COUNT(*) c FROM users WHERE role='customer'").c;
    const totalReps = db.get("SELECT COUNT(*) c FROM users WHERE role='rep'").c;
    const totalOrders = db.get('SELECT COUNT(*) c FROM orders').c;
    const ordersByStatus = db.all('SELECT status, COUNT(*) c FROM orders GROUP BY status');
    const revenue = db.get("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status != 'canceled'").s;
    res.json({ totalCustomers, totalReps, totalOrders, ordersByStatus, revenue });
  });

  /* ---------- Auditoria ---------- */
  router.get('/api/admin/audit', admin, (req, res) => {
    res.json({ entries: audit.list(300) });
  });
};
