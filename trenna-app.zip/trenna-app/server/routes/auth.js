// server/routes/auth.js
'use strict';
const db = require('../db');
const { hashPassword, verifyPassword, randomToken, sha256 } = require('../lib/password');
const session = require('../lib/session');
const ratelimit = require('../lib/ratelimit');
const mailer = require('../lib/mailer');
const audit = require('../lib/audit');
const { requireAuth, requireCsrf } = require('../lib/middleware');

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
}

function publicUser(u) {
  if (!u) return null;
  const { password_hash, ...rest } = u;
  return rest;
}

module.exports = function registerAuthRoutes(router) {
  router.get('/api/auth/csrf', (req, res) => {
    const token = session.ensureCsrfCookie(req, res);
    res.json({ csrfToken: token });
  });

  router.get('/api/auth/me', (req, res) => {
    const user = session.currentUser(req);
    res.json({ user: publicUser(user) });
  });

  router.post('/api/auth/login', requireCsrf, (req, res, next) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const key = `login:${clientIp(req)}:${email}`;
    const rl = ratelimit.check(key);
    if (!rl.allowed) {
      return next(Object.assign(new Error('Muitas tentativas de login. Tente novamente em alguns minutos.'), { status: 429 }));
    }
    const user = db.get('SELECT * FROM users WHERE email = ? AND active = 1', [email]);
    if (!user || !verifyPassword(password, user.password_hash)) {
      ratelimit.hit(key);
      return next(Object.assign(new Error('E-mail ou senha incorretos.'), { status: 401 }));
    }
    ratelimit.reset(key);
    const { token } = session.createSession(user.id);
    session.setSessionCookie(res, token, { secure: req.headers['x-forwarded-proto'] === 'https' });
    audit.log(user.id, 'auth.login', 'user', user.id, null);
    res.json({ user: publicUser(user) });
  });

  router.post('/api/auth/logout', (req, res) => {
    const cookies = session.parseCookies(req);
    session.destroySession(cookies[session.COOKIE_NAME]);
    session.clearSessionCookie(res);
    res.json({ ok: true });
  });

  router.post('/api/auth/password/change', requireAuth(), requireCsrf, (req, res, next) => {
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || String(newPassword).length < 8) {
      return next(Object.assign(new Error('A nova senha deve ter pelo menos 8 caracteres.'), { status: 400 }));
    }
    const user = db.get('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (!verifyPassword(currentPassword || '', user.password_hash)) {
      return next(Object.assign(new Error('Senha atual incorreta.'), { status: 401 }));
    }
    db.run('UPDATE users SET password_hash = ? WHERE id = ?', [hashPassword(newPassword), user.id]);
    audit.log(user.id, 'auth.password_changed', 'user', user.id, null);
    res.json({ ok: true });
  });

  router.post('/api/auth/password/forgot', requireCsrf, async (req, res, next) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const key = `forgot:${clientIp(req)}:${email}`;
    const rl = ratelimit.check(key);
    // Resposta é sempre genérica (não revela se o e-mail existe), mas o
    // rate limit evita abuso de qualquer forma.
    if (rl.allowed) {
      ratelimit.hit(key);
      const user = db.get('SELECT * FROM users WHERE email = ? AND active = 1', [email]);
      if (user) {
        const token = randomToken(32);
        const expires = new Date(Date.now() + 3600000).toISOString(); // 1 hora
        db.run('INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?,?,?)', [sha256(token), user.id, expires]);
        const base = process.env.APP_URL || `http://${req.headers.host}`;
        const link = `${base}/reset-password.html?token=${token}`;
        try {
          await mailer.send({
            to: user.email, subject: 'Recuperação de senha — Trenna Distribuição',
            text: `Olá, ${user.name}. Clique no link para redefinir sua senha (válido por 1 hora): ${link}\n\nSe você não pediu isso, ignore este e-mail.`
          });
        } catch (e) { console.error('[mailer] falha ao enviar:', e.message); }
        audit.log(user.id, 'auth.password_reset_requested', 'user', user.id, null);
      }
    }
    res.json({ ok: true, message: 'Se o e-mail existir em nossa base, você receberá um link de redefinição.' });
  });

  router.post('/api/auth/password/reset', requireCsrf, (req, res, next) => {
    const { token, password } = req.body;
    if (!password || String(password).length < 8) {
      return next(Object.assign(new Error('A nova senha deve ter pelo menos 8 caracteres.'), { status: 400 }));
    }
    const row = db.get(
      `SELECT * FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > datetime('now')`,
      [sha256(String(token || ''))]
    );
    if (!row) return next(Object.assign(new Error('Link inválido ou expirado. Solicite uma nova recuperação de senha.'), { status: 400 }));
    db.transaction(() => {
      db.run('UPDATE users SET password_hash = ? WHERE id = ?', [hashPassword(password), row.user_id]);
      db.run('UPDATE password_resets SET used = 1 WHERE token_hash = ?', [row.token_hash]);
    });
    audit.log(row.user_id, 'auth.password_reset_completed', 'user', row.user_id, null);
    res.json({ ok: true });
  });
};
