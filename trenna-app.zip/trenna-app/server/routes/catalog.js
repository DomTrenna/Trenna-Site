// server/routes/catalog.js
'use strict';
const db = require('../db');

module.exports = function registerCatalogRoutes(router) {
  // Lista departamentos (para popular o filtro do front-end)
  router.get('/api/catalog/departments', (req, res) => {
    const rows = db.all('SELECT DISTINCT department FROM products WHERE department IS NOT NULL ORDER BY department');
    res.json({ departments: rows.map(r => r.department) });
  });

  // Busca paginada: /api/catalog/products?q=...&department=...&sort=name-asc&offset=0&limit=30
  router.get('/api/catalog/products', (req, res) => {
    const { q = '', department = '', sort = 'relevance' } = req.query;
    const limit = Math.min(parseInt(req.query.limit, 10) || 30, 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);

    const where = [];
    const params = [];
    if (department) { where.push('department = ?'); params.push(department); }
    if (q) {
      where.push('(name LIKE ? OR brand LIKE ? OR code LIKE ?)');
      const like = `%${q}%`;
      params.push(like, like, like);
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';

    let orderSql = '';
    if (sort === 'name-asc') orderSql = 'ORDER BY name ASC';
    else if (sort === 'name-desc') orderSql = 'ORDER BY name DESC';
    else if (sort === 'department') orderSql = 'ORDER BY department ASC, name ASC';
    else orderSql = 'ORDER BY rowid ASC';

    const total = db.get(`SELECT COUNT(*) as c FROM products ${whereSql}`, params).c;
    const items = db.all(`SELECT * FROM products ${whereSql} ${orderSql} LIMIT ? OFFSET ?`, [...params, limit, offset]);
    res.json({ total, items });
  });

  router.get('/api/catalog/products/:code', (req, res, next) => {
    const product = db.get('SELECT * FROM products WHERE code = ?', [req.params.code]);
    if (!product) return next(Object.assign(new Error('Produto não encontrado.'), { status: 404 }));
    res.json({ product });
  });
};
