// server/routes/customer.js
'use strict';
const db = require('../db');
const { hashPassword, verifyPassword } = require('../lib/password');
const discount = require('../lib/discount');
const audit = require('../lib/audit');
const { requireAuth, requireCsrf } = require('../lib/middleware');

module.exports = function registerCustomerRoutes(router) {
  router.get('/api/customer/profile', requireAuth('customer'), (req, res) => {
    const u = req.user;
    res.json({
      profile: {
        id: u.id, name: u.name, email: u.email, phone: u.phone,
        companyName: u.company_name, taxId: u.tax_id,
        discountPercent: u.discount_percent, firstPurchaseUsed: !!u.first_purchase_used
      }
    });
  });

  router.put('/api/customer/profile', requireAuth('customer'), requireCsrf, (req, res) => {
    const { name, phone, companyName } = req.body;
    db.run('UPDATE users SET name = COALESCE(?,name), phone = COALESCE(?,phone), company_name = COALESCE(?,company_name) WHERE id = ?',
      [name || null, phone || null, companyName || null, req.user.id]);
    audit.log(req.user.id, 'customer.profile_updated', 'user', req.user.id, { name, phone, companyName });
    res.json({ ok: true });
  });

  // Prévia do desconto que será aplicado (mostrado no carrinho antes de finalizar)
  router.get('/api/customer/discount-preview', requireAuth('customer'), (req, res) => {
    res.json({ discount: discount.previewDiscount(req.user) });
  });

  router.get('/api/customer/orders', requireAuth('customer'), (req, res) => {
    const orders = db.all('SELECT * FROM orders WHERE customer_id = ? ORDER BY id DESC', [req.user.id]);
    const withItems = orders.map(o => ({
      ...o,
      items: db.all('SELECT * FROM order_items WHERE order_id = ?', [o.id])
    }));
    res.json({ orders: withItems });
  });

  router.post('/api/customer/checkout', requireAuth('customer'), requireCsrf, (req, res, next) => {
    const { items, deliveryMethod } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return next(Object.assign(new Error('Carrinho vazio.'), { status: 400 }));
    }
    if (!deliveryMethod) return next(Object.assign(new Error('Selecione a forma de entrega.'), { status: 400 }));
    try {
      const result = discount.createOrder({
        customerId: req.user.id, repId: req.user.rep_id,
        items: items.map(i => ({ code: String(i.code), qty: i.qty })),
        deliveryMethod
      });
      res.json(result);
    } catch (e) { next(e); }
  });
};
