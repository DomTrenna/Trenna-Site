// server/routes/rep.js
'use strict';
const db = require('../db');
const { hashPassword, randomToken, sha256 } = require('../lib/password');
const discount = require('../lib/discount');
const mailer = require('../lib/mailer');
const audit = require('../lib/audit');
const { requireAuth, requireCsrf } = require('../lib/middleware');

function publicCustomer(u) {
  const { password_hash, ...rest } = u;
  return rest;
}

module.exports = function registerRepRoutes(router) {
  // Lista só os clientes DESTE vendedor (um rep nunca vê clientes de outro,
  // a não ser que seja admin).
  router.get('/api/rep/customers', requireAuth('rep'), (req, res) => {
    const { q = '' } = req.query;
    let sql = 'SELECT * FROM users WHERE role = ? AND rep_id = ?';
    const params = ['customer', req.user.id];
    if (q) { sql += ' AND (name LIKE ? OR company_name LIKE ? OR email LIKE ?)'; const like = `%${q}%`; params.push(like, like, like); }
    sql += ' ORDER BY created_at DESC';
    res.json({ customers: db.all(sql, params).map(publicCustomer) });
  });

  router.post('/api/rep/customers', requireAuth('rep'), requireCsrf, async (req, res, next) => {
    const { name, email, phone, companyName, taxId } = req.body;
    if (!name || !email) return next(Object.assign(new Error('Nome e e-mail são obrigatórios.'), { status: 400 }));
    const emailNorm = String(email).trim().toLowerCase();
    const exists = db.get('SELECT id FROM users WHERE email = ?', [emailNorm]);
    if (exists) return next(Object.assign(new Error('Já existe um usuário com este e-mail.'), { status: 409 }));

    // Senha inicial: um valor aleatório que ninguém usa — o cliente DEFINE a
    // própria senha pelo link de criação de senha (reaproveita o fluxo de
    // "esqueci minha senha").
    const placeholder = hashPassword(randomToken(24));
    const r = db.run(
      `INSERT INTO users (role, name, email, phone, company_name, tax_id, password_hash, rep_id)
       VALUES ('customer', ?,?,?,?,?,?,?)`,
      [name, emailNorm, phone || null, companyName || null, taxId || null, placeholder, req.user.id]
    );
    const customerId = r.lastInsertRowid;
    audit.log(req.user.id, 'customer.created', 'user', customerId, { name, email: emailNorm });

    const token = randomToken(32);
    const expires = new Date(Date.now() + 72 * 3600000).toISOString(); // 72h para criar a senha
    db.run('INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?,?,?)', [sha256(token), customerId, expires]);
    const base = process.env.APP_URL || `http://${req.headers.host}`;
    const link = `${base}/reset-password.html?token=${token}`;
    try {
      await mailer.send({
        to: emailNorm, subject: 'Bem-vindo(a) à Trenna Distribuição — crie sua senha',
        text: `Olá, ${name}! Sua conta foi criada pelo nosso time comercial. Crie sua senha de acesso (link válido por 72h): ${link}`
      });
    } catch (e) { console.error('[mailer] falha ao enviar convite:', e.message); }

    res.status(201).json({ ok: true, customerId, setPasswordLink: link });
  });

  router.put('/api/rep/customers/:id', requireAuth('rep'), requireCsrf, (req, res, next) => {
    const customer = db.get('SELECT * FROM users WHERE id = ? AND role = ? AND rep_id = ?', [req.params.id, 'customer', req.user.id]);
    if (!customer) return next(Object.assign(new Error('Cliente não encontrado.'), { status: 404 }));
    const { name, phone, companyName, taxId } = req.body;
    db.run('UPDATE users SET name = COALESCE(?,name), phone = COALESCE(?,phone), company_name = COALESCE(?,company_name), tax_id = COALESCE(?,tax_id) WHERE id = ?',
      [name || null, phone || null, companyName || null, taxId || null, customer.id]);
    audit.log(req.user.id, 'customer.updated', 'user', customer.id, req.body);
    res.json({ ok: true });
  });

  router.put('/api/rep/customers/:id/discount', requireAuth('rep'), requireCsrf, (req, res, next) => {
    const customer = db.get('SELECT * FROM users WHERE id = ? AND role = ? AND rep_id = ?', [req.params.id, 'customer', req.user.id]);
    if (!customer) return next(Object.assign(new Error('Cliente não encontrado.'), { status: 404 }));
    try {
      discount.assignDiscount({
        actorId: req.user.id, actorRole: 'rep', repMax: req.user.max_discount_percent,
        customerId: customer.id, percent: req.body.percent
      });
      res.json({ ok: true });
    } catch (e) { next(e); }
  });

  router.get('/api/rep/orders', requireAuth('rep'), (req, res) => {
    const orders = db.all(
      `SELECT o.*, u.name as customer_name FROM orders o JOIN users u ON u.id = o.customer_id
       WHERE o.rep_id = ? ORDER BY o.id DESC`, [req.user.id]
    );
    res.json({ orders });
  });

  router.get('/api/rep/me', requireAuth('rep'), (req, res) => {
    res.json({ maxDiscountPercent: req.user.max_discount_percent });
  });
};
