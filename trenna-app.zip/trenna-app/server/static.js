// server/static.js
// Serve arquivos estáticos de /public (CSS, JS, imagens, favicon etc.).
// Simples de propósito: sem dependências externas.
'use strict';
const fs = require('node:fs');
const path = require('node:path');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json',
  '.xml': 'application/xml', '.txt': 'text/plain; charset=utf-8'
};

function serveStatic(rootDir) {
  const root = path.resolve(rootDir);
  return (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    const safePath = path.normalize(decodeURIComponent(req.pathname)).replace(/^(\.\.[/\\])+/, '');
    const filePath = path.join(root, safePath);
    if (!filePath.startsWith(root)) { res.statusCode = 403; return res.end('Forbidden'); }
    fs.stat(filePath, (err, stat) => {
      if (err || !stat.isFile()) return next();
      const ext = path.extname(filePath).toLowerCase();
      res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
      if (ext === '.webp' || ext === '.jpg' || ext === '.jpeg' || ext === '.png') {
        res.setHeader('Cache-Control', 'public, max-age=2592000'); // 30 dias — fotos de produto raramente mudam
      }
      fs.createReadStream(filePath).pipe(res);
    });
  };
}

module.exports = { serveStatic };
